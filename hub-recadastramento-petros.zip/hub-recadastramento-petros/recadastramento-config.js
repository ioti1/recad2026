window.RECADASTRAMENTO_CONFIG = {
  "version": 1,
  "updatedAt": "2026-08-18T03:00:00.000Z",
  "applications": [
    {
      "id": "formulario-recadastramento",
      "name": "Formulário de Recadastramento",
      "description": "Acesso ao fluxo principal para revisão e confirmação dos dados cadastrais.",
      "category": "Operação",
      "path": "#",
      "icon": "form",
      "accent": "#087e82",
      "target": "_blank",
      "status": "Disponível"
    },
    {
      "id": "consulta-pendencias",
      "name": "Consulta de Pendências",
      "description": "Acompanhe documentos, dados obrigatórios e etapas que ainda precisam de atenção.",
      "category": "Acompanhamento",
      "path": "#",
      "icon": "check",
      "accent": "#2c758c",
      "target": "_blank",
      "status": "Disponível"
    },
    {
      "id": "validacao-documental",
      "name": "Validação Documental",
      "description": "Central de conferência e tratamento dos documentos enviados pelos participantes.",
      "category": "Análise",
      "path": "#",
      "icon": "folder",
      "accent": "#9b7042",
      "target": "_blank",
      "status": "Em homologação"
    },
    {
      "id": "painel-operacional",
      "name": "Painel Operacional",
      "description": "Indicadores consolidados para apoiar a gestão diária da campanha.",
      "category": "Gestão",
      "path": "#",
      "icon": "chart",
      "accent": "#536aa3",
      "target": "_blank",
      "status": "Em breve"
    }
  ]
};
