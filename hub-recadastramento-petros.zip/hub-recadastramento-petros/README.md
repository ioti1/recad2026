# Hub de Recadastramento

Central interna de aplicações do Recadastramento — Cadastro Analytics / GAP-CA.

## Publicação

O projeto é estático e não exige instalação ou compilação. Para publicar no GitHub Pages, envie os arquivos para a raiz do repositório e habilite o Pages usando a branch principal.

## Arquivos

- `index.html`: aplicação completa.
- `recadastramento-config.js`: fonte compartilhada carregada automaticamente por todos os acessos.
- `recadastramento-config.json`: configuração inicial dos atalhos.
- `recadastramento-campanha.jpg`: imagem utilizada no banner.

## Administração

Senha inicial: `Petros2026`

O painel administrativo permite criar, editar, duplicar e excluir aplicações, além de importar e exportar backups em JSON. Enquanto o administrador edita, as alterações são mantidas como rascunho somente naquele navegador.

Para disponibilizar as alterações às outras pessoas, use **Publicar para todos** e escolha um dos modos:

### Pasta compartilhada / OneDrive

Selecione ou crie exatamente o arquivo `recadastramento-config.js` que fica na mesma pasta do `index.html`. O navegador guarda a autorização desse arquivo no computador do administrador e os próximos salvamentos poderão sobrescrevê-lo diretamente. O OneDrive ou a pasta de rede distribui o arquivo atualizado aos demais usuários.

### GitHub Pages

Informe proprietário, repositório, branch e um token fine-grained restrito ao repositório, com permissão **Contents: Read and write**. O token é enviado apenas à API oficial do GitHub durante aquela publicação e não é armazenado. O Hub cria um commit atualizando `recadastramento-config.js`; o GitHub Pages normalmente distribui a alteração em seguida.

O botão **Exportar JSON** cria somente um backup e não publica para os demais.

> O login é uma proteção de interface para um site estático e não substitui autenticação corporativa no servidor.
