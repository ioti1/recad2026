# Hub de Recadastramento

Central interna de aplicações do Recadastramento — Cadastro Analytics / GAP-CA.

## Publicação

O projeto é estático e não exige instalação ou compilação. Para publicar no GitHub Pages, envie os arquivos para a raiz do repositório e habilite o Pages usando a branch principal.

## Arquivos

- `index.html`: aplicação completa.
- `recadastramento-config.json`: configuração inicial dos atalhos.
- `recadastramento-campanha.jpg`: imagem utilizada no banner.

## Administração

Senha inicial: `Petros2026`

O painel administrativo permite criar, editar, duplicar e excluir aplicações, além de importar e exportar a configuração em JSON. Cada alteração é salva automaticamente no navegador, com uma cópia redundante no banco local, e volta na próxima abertura. Os botões **Salvar configuração** e **Exportar JSON** também forçam uma gravação completa antes de concluir a ação.

Para distribuir a mesma configuração para outros usuários ou computadores, exporte o JSON e substitua o arquivo `recadastramento-config.json` do projeto. A persistência automática do navegador é específica para aquele navegador e endereço do hub.

> O login é uma proteção de interface para um site estático e não substitui autenticação corporativa no servidor.
