# Hub de Recadastramento

Central interna de aplicações do Recadastramento — Cadastro Analytics / GAP-CA.

## Publicação

O projeto é estático e não exige instalação ou compilação. Para publicar no GitHub Pages, envie os arquivos para a raiz do repositório e habilite o Pages usando a branch principal.

## Arquivos

- `index.html`: aplicação completa.
- `recadastramento-config.json`: configuração inicial dos atalhos.
- `recadastramento-campanha.jpg`: imagem utilizada no banner.

## Administração

Senha inicial: `Petros2026`

O painel administrativo permite criar, editar, duplicar e excluir aplicações, além de importar e exportar a configuração em JSON. As alterações feitas pelo painel são armazenadas no navegador. Para distribuir uma configuração atualizada, exporte o JSON e substitua o arquivo `recadastramento-config.json` do projeto.

> O login é uma proteção de interface para um site estático e não substitui autenticação corporativa no servidor.
